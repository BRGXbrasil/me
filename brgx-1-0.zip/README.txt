BRGX 1.0

Suba este ZIP em Deploys no Netlify para atualizar https://borgex.netlify.app/.
Depois abra pelo Safari. Se o iPhone mantiver versão antiga, remova o ícone da tela inicial e adicione novamente.

Versão inclui limpeza automática de service worker/cache antigo.
